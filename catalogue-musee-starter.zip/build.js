// Script de génération (voir plus haut pour version complète)
